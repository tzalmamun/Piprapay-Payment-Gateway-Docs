<?php
    class PaystationGateway
    {
        public function info()
        {
            return [
                'title'       => 'PayStation Gateway',
                'logo'        => 'assets/logo.jpg',
                'currency'        => 'BDT',
                'tab'        => 'mfs',

                'gateway_type'        => 'api',
            ];
        }

        public function color()
        {
            return [
                'primary_color'        => '#351e53',
                'text_color'        => '#FFFFFF',
                'btn_color'        => '#351e53',
                'btn_text_color'        => '#FFFFFF',
            ];
        }

        public function fields()
        {
            return [
                [
                    'name'  => 'merchant_id',
                    'label' => 'Merchant ID',
                    'type'  => 'text',
                ],
                [
                    'name'  => 'merchant_password',
                    'label' => 'Merchant Password',
                    'type'  => 'text',
                ],
                [
                    'name'  => 'checkout_items',
                    'label' => 'Checkout items',
                    'type'  => 'text',
                ],
                [
                    'name'  => 'pay_with_charge',
                    'label' => 'Who pay fees?',
                    'type'  => 'select',
                    'options' => [
                        '0'  => 'Customer',
                        '1' => 'Merchant',
                    ],
                    'value' => '0',
                    'required' => true,
                    'multiple' => false,
                ],
                [
                    'name'  => 'mode',
                    'label' => 'Mode',
                    'type'  => 'select',
                    'options' => [
                        'live'  => 'Live',
                        'sandbox' => 'Sandbox',
                    ],
                    'value' => 'live',
                    'required' => true,
                    'multiple' => false,
                ],
            ];
        }

        function process_payment($data = []){
            echo '<center><div class="spinner-border text-primary m-3 loading-123412341234" role="status"><span class="visually-hidden">Loading...</span></div></center>';

            $base_url = (($data['options']['mode'] ?? 'sandbox') === 'live') ? 'https://api.paystation.com.bd' : 'https://sandbox.paystation.com.bd';

            $curl = curl_init();
            
            $postFields = array(
                'invoice_number' => rand(),
                'currency' => 'BDT',
                'payment_amount' => $data['transaction']['local_net_amount'],
                'reference' => rand(),
                'cust_name' => $data['transaction']['customer']['name'],
                'cust_phone' => $data['transaction']['customer']['mobile'],
                'cust_email' => $data['transaction']['customer']['email'],
                'cust_address' => "Bangladesh",
                'pay_with_charge' => ($data['options']['pay_with_charge'] ?? '0'),
                'callback_url' => pp_callback_url(),
            
                'checkout_items' => ($data['options']['checkout_items'] ?? ''),
            
                'merchantId' => ($data['options']['merchant_id'] ?? ''),
                'password' => ($data['options']['merchant_password'] ?? '')
            );
            
            curl_setopt_array($curl, array(
                CURLOPT_URL => $base_url."/initiate-payment",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => $postFields,
            ));
            
            $response = curl_exec($curl);
            curl_close($curl);
            
            $response_curl = json_decode($response, true);

            if(isset($response_curl['payment_url'])){
               echo '<script>location.href="' . $response_curl['payment_url'] . '";</script>';
            }else{
                echo '<div class="alert alert-danger" role="alert">'.$response.'</div> <style>.loading-123412341234{display: none;}</style>';
            }
        }

        function callback($data = []){
            echo '<center><div class="spinner-border text-primary m-3 loading-123412341234" role="status"><span class="visually-hidden">Loading...</span></div></center>';

            $base_url = (($data['options']['mode'] ?? 'sandbox') === 'live') ? 'https://api.paystation.com.bd' : 'https://sandbox.paystation.com.bd';

            $status = $_GET['status'] ?? '';

            if($status == "Canceled"){
                echo '<div class="alert alert-danger" role="alert">Transaction Canceled.</div><style>.loading-123412341234{display: none;}</style>';
            }else{
                $invoice_number = $_GET['invoice_number'] ?? '';
                $trx_id = $_GET['trx_id'] ?? '';

                $header=array('merchantId:'.$data['options']['merchant_id']);
                $body=array('invoice_number' => $invoice_number);

                $url = curl_init($base_url.'/transaction-status');
                curl_setopt($url,CURLOPT_HTTPHEADER, $header);
                curl_setopt($url,CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($url,CURLOPT_RETURNTRANSFER, true);
                curl_setopt($url,CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($url,CURLOPT_POSTFIELDS, $body);
                curl_setopt($url,CURLOPT_FOLLOWLOCATION, 1);
                $responseData=curl_exec($url);
                curl_close($url);
                
                $decode_response = json_decode($responseData, true);
                
                if($decode_response['status_code'] == "200" && $decode_response['status'] == "success"){
                    if($decode_response['data']['trx_status'] == "successful" || $decode_response['data']['trx_status'] == "Success"){
                        $verified_order_id = $decode_response['data']['invoice_number'];
                        $verified_trx_id = $decode_response['data']['trx_id'];
                        $payer_mobile_no = $decode_response['data']['payer_mobile_no'];
                        $payment_method = $decode_response['data']['payment_method'];
                        
                        $moreinfo = [
                            [
                                'label' => 'Invoice Number',
                                'value' => $verified_order_id
                            ],
                            [
                                'label' => 'Payer Mobile Number',
                                'value' => $payer_mobile_no
                            ],
                            [
                                'label' => 'Financial Entity',
                                'value' => $payment_method
                            ]
                        ];

                        pp_set_transaction_status($data['transaction']['ref'], 'completed', $data['gateway']['gateway_id'], $verified_trx_id, $moreinfo);

                        echo "<script>location.reload();</script>";
                    }else{
                        echo '<div class="alert alert-danger" role="alert">'.$responseData.'</div>';
                    }
                }else{
                    echo '<div class="alert alert-danger" role="alert">'.$responseData.'</div>';
                }
            }
        }
    }
